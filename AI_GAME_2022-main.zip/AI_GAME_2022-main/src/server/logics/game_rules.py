# change_it
GEM_SCORES = [50, 100, 200, 300]

HIT_HURT = -20
BARBED_HURT = -20
STRAIGHT_MOVE_HURT = -1
DIAGONAL_MOVE_HURT = -2

GEM_SEQUENCE_SCORE = [
    [50,   0,   0, 0],
    [50, 200, 100, 0],
    [100, 50, 200, 100],
    [50, 100, 50,  200],
    [250, 50, 100, 50]

]
